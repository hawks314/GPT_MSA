package com.hawks314.gpt_msa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GptMsaApplicationTests {

	@Test
	void contextLoads() {
	}

}
