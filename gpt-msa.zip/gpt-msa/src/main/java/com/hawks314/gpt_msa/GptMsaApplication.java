package com.hawks314.gpt_msa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GptMsaApplication {

	public static void main(String[] args) {
		SpringApplication.run(GptMsaApplication.class, args);
	}

}
